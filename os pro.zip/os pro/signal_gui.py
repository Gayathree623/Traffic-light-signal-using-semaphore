import subprocess
import threading
import tkinter as tk

# Function to update the GUI based on C program output
def update_signal_state(output_line):
    output_line = output_line.strip()
    if output_line.startswith("GREEN"):
        direction = output_line.split()[1]
        signal_labels[direction].config(bg="green", text=f"{direction}\nGREEN")
    elif output_line.startswith("RED"):
        direction = output_line.split()[1]
        signal_labels[direction].config(bg="red", text=f"{direction}\nRED")

# Function to run the C program and read its output
def run_c_program():
    global c_process
    try:
        # ✅ Use full path to your C executable
        c_process = subprocess.Popen(
            [r"C:\os pro\signal.exe"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )

        for line in c_process.stdout:
            print("C output:", line.strip())  # Debug print
            update_signal_state(line)

    except FileNotFoundError:
        print("❌ Error: signal.exe not found at specified path.")
    except Exception as e:
        print("❌ General error while running signal.exe:", e)

# Graceful shutdown
def on_close():
    if c_process:
        c_process.terminate()
    root.destroy()

# GUI setup
root = tk.Tk()
root.title("4-Way Traffic Signal Controller")

# Use a grid layout to mimic a road intersection
frame = tk.Frame(root, padx=20, pady=20)
frame.pack()

signal_labels = {}

# NORTH
signal_labels["North"] = tk.Label(frame, text="North\nRED", bg="red", fg="white", font=("Arial", 14), width=12, height=3)
signal_labels["North"].grid(row=0, column=1, pady=10)

# WEST
signal_labels["West"] = tk.Label(frame, text="West\nRED", bg="red", fg="white", font=("Arial", 14), width=12, height=3)
signal_labels["West"].grid(row=1, column=0, padx=10)

# EAST
signal_labels["East"] = tk.Label(frame, text="East\nRED", bg="red", fg="white", font=("Arial", 14), width=12, height=3)
signal_labels["East"].grid(row=1, column=2, padx=10)

# SOUTH
signal_labels["South"] = tk.Label(frame, text="South\nRED", bg="red", fg="white", font=("Arial", 14), width=12, height=3)
signal_labels["South"].grid(row=2, column=1, pady=10)

# Center (intersection box)
intersection = tk.Label(frame, text="Intersection", bg="gray", fg="white", font=("Arial", 12), width=15, height=2)
intersection.grid(row=1, column=1, padx=10, pady=10)

# Quit button
quit_button = tk.Button(root, text="Quit", command=on_close, font=("Arial", 14))
quit_button.pack(pady=10)

# Start C program in a separate thread
c_process = None
threading.Thread(target=run_c_program, daemon=True).start()

# Handle GUI window close
root.protocol("WM_DELETE_WINDOW", on_close)

# Start the GUI loop
root.mainloop()
