#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define NUM_DIRECTIONS 4

const char* directions[] = {"North", "South", "East", "West"};
int passengers[NUM_DIRECTIONS];

typedef struct {
    int dir;
    int passengers;
} Signal;

Signal queue[NUM_DIRECTIONS];

sem_t sems[NUM_DIRECTIONS];

// Comparator for sorting signals by priority (passenger count descending)
int compare(const void* a, const void* b) {
    Signal* s1 = (Signal*)a;
    Signal* s2 = (Signal*)b;
    return s2->passengers - s1->passengers;
}

void* signal_controller(void* arg) {
    int dir = *(int*)arg;

    // Wait until the semaphore is unlocked
    sem_wait(&sems[dir]);

    // Simulate signal ON for this direction
    printf("Signal ON for %s | Passengers: %d\n", directions[dir], passengers[dir]);
    sleep(3); // Signal ON duration
    printf("Signal OFF for %s\n", directions[dir]);

    pthread_exit(NULL);
}

int main() {
    printf("Enter the number of passengers in each direction:\n");
    for (int i = 0; i < NUM_DIRECTIONS; i++) {
        printf("%s: ", directions[i]);
        scanf("%d", &passengers[i]);
        queue[i].dir = i;
        queue[i].passengers = passengers[i];
        sem_init(&sems[i], 0, 0);
    }

    // Sort by priority
    qsort(queue, NUM_DIRECTIONS, sizeof(Signal), compare);

    pthread_t threads[NUM_DIRECTIONS];
    int dir_ids[NUM_DIRECTIONS];

    for (int i = 0; i < NUM_DIRECTIONS; i++) {
        dir_ids[i] = queue[i].dir;
        pthread_create(&threads[i], NULL, signal_controller, &dir_ids[i]);
        sem_post(&sems[queue[i].dir]);
        sleep(3); // Wait before next signal
    }

    for (int i = 0; i < NUM_DIRECTIONS; i++) {
        pthread_join(threads[i], NULL);
        sem_destroy(&sems[i]);
    }

    return 0;
}
