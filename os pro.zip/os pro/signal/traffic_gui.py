import tkinter as tk
from threading import Thread
import subprocess
import time

directions = ["North", "South", "East", "West"]

light_positions = {
    "North": (200, 50),
    "South": (200, 350),
    "East": (350, 200),
    "West": (50, 200)
}

class TrafficGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Traffic Signal Controller")

        self.canvas = tk.Canvas(root, width=400, height=400, bg="lightgrey")
        self.canvas.pack()

        self.draw_road()
        self.lights = self.create_lights()

        self.entries = {}
        entry_frame = tk.Frame(root)
        entry_frame.pack(pady=10)
        tk.Label(entry_frame, text="Enter number of passengers: ", font=("Arial", 12)).grid(row=0, column=0, columnspan=2)

        for idx, dir in enumerate(directions):
            tk.Label(entry_frame, text=f"{dir}:").grid(row=idx+1, column=0)
            entry = tk.Entry(entry_frame, width=5)
            entry.grid(row=idx+1, column=1)
            self.entries[dir] = entry

        tk.Button(root, text="Start Signal", command=self.start_signal).pack(pady=10)

    def draw_road(self):
        # Draw horizontal and vertical roads
        self.canvas.create_rectangle(150, 0, 250, 400, fill="black")  # vertical road
        self.canvas.create_rectangle(0, 150, 400, 250, fill="black")  # horizontal road

        # Arrows
        self.canvas.create_line(200, 10, 200, 100, arrow=tk.LAST, fill="white", width=2) # North
        self.canvas.create_line(200, 390, 200, 300, arrow=tk.LAST, fill="white", width=2) # South
        self.canvas.create_line(390, 200, 300, 200, arrow=tk.LAST, fill="white", width=2) # East
        self.canvas.create_line(10, 200, 100, 200, arrow=tk.LAST, fill="white", width=2) # West

        # Direction Labels
        self.canvas.create_text(200, 20, text="North", fill="white", font=("Arial", 10))
        self.canvas.create_text(200, 380, text="South", fill="white", font=("Arial", 10))
        self.canvas.create_text(380, 200, text="East", fill="white", font=("Arial", 10))
        self.canvas.create_text(20, 200, text="West", fill="white", font=("Arial", 10))

    def create_lights(self):
        lights = {}
        for dir, pos in light_positions.items():
            x, y = pos
            light = self.canvas.create_oval(x-10, y-10, x+10, y+10, fill="red")
            lights[dir] = light
        return lights

    def set_signal(self, direction, state):
        for dir, light in self.lights.items():
            self.canvas.itemconfig(light, fill="red")
        if direction in self.lights and state == "GREEN":
            self.canvas.itemconfig(self.lights[direction], fill="green")

    def start_signal(self):
        input_lines = ""
        try:
            for dir in directions:
                val = int(self.entries[dir].get())
                input_lines += f"{val}\n"
        except ValueError:
            print("Please enter valid numbers!")
            return

        thread = Thread(target=self.run_c_program, args=(input_lines,))
        thread.daemon = True
        thread.start()

    def run_c_program(self, input_data):
        # Windows expects traffic.exe (make sure it's compiled)
        proc = subprocess.Popen(["traffic.exe"], stdout=subprocess.PIPE, stdin=subprocess.PIPE, text=True)

        proc.stdin.write(input_data)
        proc.stdin.flush()

        for line in proc.stdout:
            line = line.strip()
            print("[C OUTPUT]:", line)
            if "Signal ON for" in line:
                dir = line.split("Signal ON for ")[1].split(" ")[0]
                self.root.after(0, self.set_signal, dir, "GREEN")
            elif "Signal OFF for" in line:
                dir = line.split("Signal OFF for ")[1]
                self.root.after(0, self.set_signal, dir, "RED")

if __name__ == "__main__":
    root = tk.Tk()
    app = TrafficGUI(root)
    root.mainloop()
